package hw04;

public class test {
	public static void main(String[] args) {
		String city = "Turlock city";
		int pop = 68549;
		UnbalancedMap<String, Integer> x = new UnbalancedMap<String, Integer>();
		
		x.put(city, pop);
		System.out.println(x.get(city));
//		x.get(city);
	}
}
