package hw04;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class UnbalancedMap<K extends Comparable<K>, V> implements SimplerMap<K, V> {
    Node<K, V> root;

    public static class Node<K extends Comparable<K>, V> {
        public K key;
        public V value;
        public Node<K, V> left, right;

        public Node(K key, V value) {
            this.key = key;
            this.value = value;
        }

        boolean containsKey(K key) {
            int cmp = key.compareTo(this.key);
            if (cmp == 0) {
                return true;
            } else if (cmp < 0) {
                // Same as return left == null ? false : left.containsKey(key);
                // Same as if (left == null) { return false; } else { return left.containsKey(key); }
                return left != null && left.containsKey(key);
            } else {  // if (cmp > 0) {
                return right != null && right.containsKey(key);
            }
        }

        V get(K key) {
        	System.out.println("TESTING");
        	return null;
        }

        void put(K key, V value) { // EDITED: The original assignment returned V, like java.util.Map
            // TODO
        	System.out.println(key);
        	System.out.println(value);
        	this.key = key;
        	this.value = value;
        }

        int size() {
            return -1;  // TODO
        }

        // Note: You do not need to implement toString, but you probably should for your own debugging.
        //   Feel free to share your implementation of toString with other students.

        //
        // Extra Credit
        //
        // Set<K> keySet() {
        //     Set<K> keys = new TreeSet<>();
        //     // TODO
        //     return keys;
        // }
    }

    @Override
    public void clear() {
        root = null;
    }

    @Override
    public boolean containsKey(K key) {
        return root == null ? false : root.containsKey(key);
    }

    @Override
    public V get(K key) {
        return null;  // TODO
    }

    @Override
    public boolean isEmpty() {
        return root == null;
    }

    @Override
    public void put(K key, V value) {  // EDITED: The original assignment returned V, like java.util.Map
        if (root == null) {
            root = new Node<>(key, value);
        } else {
            root.put(key, value);
        }
    }

    @Override
    public int size() {
        return -12345;  // TODO
    }

    //
    // Extra Credit
    //

    // @Override
    // public Set<K> keySet() {
    //     return root.keySet();
    // }

    // @Override
    // public void putAll(Map<? extends K, ? extends V> builtinMap) {
    //     // TODO
    // }

    @Override
    public String toString() {  // NOTE: You will not be tested on .toString() but you may want to implement it so it's easier for you to debug.
        return root == null ? "<empty>" : root.toString();
    }
}